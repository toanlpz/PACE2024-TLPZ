#pragma once

#include <stdint.h>

#include "pacegraph.h"


uint64_t count_crossings(graph* g, uint32_t* ordering);